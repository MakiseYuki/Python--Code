#
# Example file for working with classes
#


def main():

  
if __name__ == "__main__":
  main()
