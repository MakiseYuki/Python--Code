#
# Example file for HelloWorld
#

def main():
    print("Hello World This is Python3")

if __name__ == "__main__":
    main()